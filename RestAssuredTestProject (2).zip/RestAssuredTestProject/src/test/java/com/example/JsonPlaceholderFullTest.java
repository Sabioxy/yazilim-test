package com.example;

import com.github.tomakehurst.wiremock.WireMockServer;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class JsonPlaceholderFullTest {

    static WireMockServer wireMockServer = new WireMockServer(8080);

    @BeforeAll
    static void setup() {
        wireMockServer.start();
        configureFor("localhost", 8080);

        // GET /posts/1 endpoint'ini mockla
        stubFor(get("/posts/1")
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody("{\"userId\":1,\"id\":1,\"title\":\"test deneme\"}")));

        // POST /posts endpoint'ini mockla
        stubFor(post("/posts")
                .withRequestBody(matchingJsonPath("$.title"))
                .willReturn(aResponse()
                        .withStatus(201)
                        .withHeader("Content-Type", "application/json")
                        .withBody("{\"id\":101,\"userId\":1,\"title\":\"Yeni gönderi\"}")));

        RestAssured.baseURI = "http://localhost:8080";
    }

    @AfterAll
    static void teardown() {
        wireMockServer.stop();
    }

    @Test
    void getPostById_shouldReturnCorrectPost() {
        given()
                .when()
                .get("/posts/1")
                .then()
                .statusCode(200)
                .contentType(ContentType.JSON)
                .body("id", equalTo(1))
                .body("userId", equalTo(1))
                .body("title", equalTo("test deneme"));
    }

    @Test
    void createPost_shouldReturnCreatedPost() {
        given()
                .contentType(ContentType.JSON)
                .body("{\"userId\":1,\"title\":\"Yeni gönderi\"}")
                .when()
                .post("/posts")
                .then()
                .statusCode(201)
                .contentType(ContentType.JSON)
                .body("id", equalTo(101))
                .body("userId", equalTo(1))
                .body("title", equalTo("Yeni gönderi"));
    }
}
